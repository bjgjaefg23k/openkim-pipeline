ASE tutorial example
=====================

A very basic test using the Atomic Simulation Environment (ASE) 
and Python binding for the OpenKIM API.  In this test, we gather
the Iron body center cubic lattice constant from the OpenKIM 
database.  Using this lattice constant, we set up a single atom 
unit cell and calculate it's energy, reporting it as the
cohesive energy.

